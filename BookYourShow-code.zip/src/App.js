import React from "react";
import "./App.css";
import "./styles.css";
import MovieShow from "./movieShow";
function App() {
  return (
    <>
      <MovieShow />
    </>
  );
}

export default App;

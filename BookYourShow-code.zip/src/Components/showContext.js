import React, { createContext } from "react";

const ShowContext = createContext();

export default ShowContext;
